class VTTAIconizerLibrary {
  constructor(iconData) {
    this.iconData = iconData;
  }
}
